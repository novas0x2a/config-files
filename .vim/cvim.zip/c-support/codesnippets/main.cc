#include	<cstdlib>
#include	<fstream>
#include	<iomanip>   
#include	<iostream>  

using namespace std;

// ===  FUNCTION  ======================================================================
//         Name:  main
//  Description:  main function
// =====================================================================================
	int
main ( int argc, char *argv[] )
{
	cout	<< "\nProgram " << argv[0] << endl << endl;

	return EXIT_SUCCESS;
}		// ----------  end of function main  ---------- 

